# CCD
grep iter ../Results/aws_ccdpp_netflix_32_4_100_0.050000.txt | cut -d' ' -f6,20 | awk 'BEGIN {srand()} !/^$/ { if (rand() <= .1) print $0}' > ../Plots/aws_ccdpp_netflix_32_4_100_0.050000.txt
grep iter ../Results/aws_ccdpp_yahoo_32_4_100_1.000000.txt | cut -d' ' -f6,20 | awk 'BEGIN {srand()} !/^$/ { if (rand() <= .1) print $0}' > ../Plots/aws_ccdpp_yahoo_32_4_100_1.000000.txt
grep iter ../Results/aws_ccdpp_hugewiki_32_4_100_0.010000.txt | cut -d' ' -f6,20 | awk 'BEGIN {srand()} !/^$/ { if (rand() <= .1) print $0}' > ../Plots/aws_ccdpp_hugewiki_32_4_100_0.010000.txt

# DSGD
grep iter ../Results/aws_dsgd_bold_wor_yahoo_32_4_100_1.000000_0.000500_0.500000.txt | cut -d' ' -f4,16 > ../Plots/aws_dsgd_bold_wor_yahoo_32_4_100_1.000000_0.000500_0.500000.txt
grep iter ../Results/aws_dsgd_bold_wor_netflix_32_4_100_0.050000_0.008000_0.500000.txt | cut -d' ' -f4,16 > ../Plots/aws_dsgd_bold_wor_netflix_32_4_100_0.050000_0.008000_0.500000.txt
grep iter ../Results/aws_dsgd_bold_wor_hugewiki_32_4_100_0.010000_0.008000_0.500000.txt | cut -d' ' -f4,16 > ../Plots/aws_dsgd_bold_wor_hugewiki_32_4_100_0.010000_0.008000_0.500000.txt

# NOMAD
rm ../Plots/aws_nomad_hugewiki_all_2_100_0.010000_0.000667_0.000000.txt
for i in 8 16 32
do
    grep testgrep ../Results/aws_nomad_hugewiki_${i}_2_100_0.010000_0.000667_0.000000.txt  > ../Plots/aws_nomad_hugewiki_${i}_2_100_0.010000_0.000667_0.000000.txt
    grep testgrep ../Results/aws_nomad_hugewiki_${i}_2_100_0.010000_0.000667_0.000000.txt >> ../Plots/aws_nomad_hugewiki_all_2_100_0.010000_0.000667_0.000000.txt
done

rm ../Plots/aws_nomad_netflix_all_2_100_0.050000_0.008000_0.010000.txt
rm ../Plots/aws_nomad_yahoo_all_2_100_1.000000_0.000500_0.050000.txt
for i in 1 2 4 8 16 32
do
    grep testgrep ../Results/aws_nomad_netflix_${i}_2_100_0.050000_0.008000_0.010000.txt | sort -t, -k2,2 -k4,4 -n > ../Plots/aws_nomad_netflix_${i}_2_100_0.050000_0.008000_0.010000.txt
    grep testgrep ../Results/aws_nomad_netflix_${i}_2_100_0.050000_0.008000_0.010000.txt | sort -t, -k2,2 -k4,4 -n >> ../Plots/aws_nomad_netflix_all_2_100_0.050000_0.008000_0.010000.txt
    grep testgrep ../Results/aws_nomad_yahoo_${i}_2_100_1.000000_0.000500_0.050000.txt | sort -t, -k2,2 -k4,4 -n > ../Plots/aws_nomad_yahoo_${i}_2_100_1.000000_0.000500_0.050000.txt
    grep testgrep ../Results/aws_nomad_yahoo_${i}_2_100_1.000000_0.000500_0.050000.txt | sort -t, -k2,2 -k4,4 -n >> ../Plots/aws_nomad_yahoo_all_2_100_1.000000_0.000500_0.050000.txt
done
