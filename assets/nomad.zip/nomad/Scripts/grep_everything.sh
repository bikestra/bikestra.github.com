for i in 4 8 16 30
do
    grep testgrep ../Results/stampede_single_nomad_hugewiki_1_${i}_100_0.010000_0.008000_0.005000.txt > ../Plots/stampede_single_nomad_hugewiki_1_${i}_100_0.010000_0.008000_0.005000.txt
done
rm ../Results/stampede_single_nomad_hugewiki_1_all_100_0.010000_0.008000_0.005000.txt
for i in 4 8 16 30
do
    grep testgrep ../Results/stampede_single_nomad_hugewiki_1_${i}_100_0.010000_0.008000_0.005000.txt >> ../Results/stampede_single_nomad_hugewiki_1_all_100_0.010000_0.008000_0.005000.txt
done
