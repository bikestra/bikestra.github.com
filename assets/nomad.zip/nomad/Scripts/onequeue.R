library(lattice)
library(plyr)

df <- read.csv("../Results/onequeue.txt", header=FALSE)
colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
df <- df[order(df$timeout),]

pdf("onequeue1.pdf")
xyplot(numupdates/numprocs/numcpus/timeout ~ numcpus, data=df, groups = numcpus, type="p", auto.key=TRUE, subset=timeout>100,
       ylim=c(0,4000000))
dev.off()
pdf("onequeue2.pdf")
xyplot(numupdates/numprocs/numcpus ~ timeout, data=df, groups = numcpus, type="b", auto.key=TRUE, subset=timeout>100)
dev.off()

df2 <- read.csv("../Results/nocomm.txt", header=FALSE)
colnames(df2) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
df2 <- df2[order(df2$timeout),]
xyplot(numupdates/numprocs/numcpus/timeout ~ numcpus, data=df2, groups = numcpus, type="p", auto.key=TRUE, subset=timeout>100,
       ylim=c(0,4000000))

df3 <- read.csv("../Results/locality.txt", header=FALSE)
colnames(df3) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
df3 <- df3[order(df3$timeout),]
xyplot(numupdates/numprocs/numcpus/timeout ~ numcpus, data=df3, groups = numcpus, type="p", auto.key=TRUE, subset=timeout>100,
       ylim=c(0,4000000))
