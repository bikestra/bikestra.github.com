
# 4.2. Scaling in Number of Cores

# nomad
rm ../Plots/stampede_single_nomad_netflix_1_all_100_0.050000_0.008000_0.010000.txt
rm ../Plots/stampede_single_nomad_yahoo_1_all_100_1.000000_0.000500_0.050000.txt
rm ../Plots/stampede_single_nomad_hugewiki_1_all_100_0.010000_0.000667_0.000000.txt
for i in 4 8 16 30
do
    grep testgrep ../Results/stampede_single_nomad_netflix_1_${i}_100_0.050000_0.008000_0.010000.txt > ../Plots/stampede_single_nomad_netflix_1_${i}_100_0.050000_0.008000_0.010000.txt
    grep testgrep ../Results/stampede_single_nomad_yahoo_1_${i}_100_1.000000_0.000500_0.050000.txt > ../Plots/stampede_single_nomad_yahoo_1_${i}_100_1.000000_0.000500_0.050000.txt
    grep testgrep ../Results/stampede_single_nomad_hugewiki_1_${i}_100_0.010000_0.000667_0.000000.txt > ../Plots/stampede_single_nomad_hugewiki_1_${i}_100_0.010000_0.000667_0.000000.txt

    grep testgrep ../Results/stampede_single_nomad_netflix_1_${i}_100_0.050000_0.008000_0.010000.txt >> ../Plots/stampede_single_nomad_netflix_1_all_100_0.050000_0.008000_0.010000.txt
    grep testgrep ../Results/stampede_single_nomad_yahoo_1_${i}_100_1.000000_0.000500_0.050000.txt >> ../Plots/stampede_single_nomad_yahoo_1_all_100_1.000000_0.000500_0.050000.txt
    grep testgrep ../Results/stampede_single_nomad_hugewiki_1_${i}_100_0.010000_0.000667_0.000000.txt >> ../Plots/stampede_single_nomad_hugewiki_1_all_100_0.010000_0.000667_0.000000.txt
done

# ccdpp
grep iter ../Results/stampede_single_ccdpp_netflix_1_30_100_0.050000.txt | cut -d' ' -f6,18 > ../Plots/stampede_single_ccdpp_netflix_1_30_100_0.050000.txt
grep iter ../Results/stampede_single_ccdpp_yahoo_1_30_100_1.000000.txt | cut -d' ' -f6,18 > ../Plots/stampede_single_ccdpp_yahoo_1_30_100_1.000000.txt
grep iter ../Results/stampede_single_ccdpp_hugewiki_1_30_100_0.010000.txt | cut -d' ' -f6,18 > ../Plots/stampede_single_ccdpp_hugewiki_1_30_100_0.010000.txt

# fpsgd
stampede_single_fpsgd_hugewiki_1_30_100_0.010000_0.001000.txt  stampede_single_fpsgd_yahoo_1_30_100_1.000000_0.000100.txt
stampede_single_fpsgd_netflix_1_30_100_0.050000_0.002000.txt
tail -n +7  ../Results/stampede_single_fpsgd_hugewiki_1_30_100_0.010000_0.001000.txt | awk '{print $2/30.0 " " $3}' > ../Plots/stampede_single_fpsgd_hugewiki_1_30_100_0.010000_0.001000.txt
tail -n +7  ../Results/stampede_single_fpsgd_yahoo_1_30_100_1.000000_0.000100.txt | awk '{print $2/30.0 " " $3}' > ../Plots/../Results/stampede_single_fpsgd_yahoo_1_30_100_1.000000_0.000100.txt
tail -n +7  ../Results/stampede_single_fpsgd_netflix_1_30_100_0.050000_0.002000.txt | awk '{print $2/30.0 " " $3}' > ../Plots/stampede_single_fpsgd_netflix_1_30_100_0.050000_0.002000.txt

# 4.3. Scaling as a Fixed Dataset is Distributed Across Processors

# nomad
rm ../Plots/stampede_multi_nomad_hugewiki_all_4_100_0.010000_0.000667_0.000000.txt
for i in 4 8 16 32 64
do
    grep testgrep ../Results/stampede_multi_nomad_hugewiki_${i}_4_100_0.010000_0.000667_0.000000.txt  > ../Plots/stampede_multi_nomad_hugewiki_${i}_4_100_0.010000_0.000667_0.000000.txt
    grep testgrep ../Results/stampede_multi_nomad_hugewiki_${i}_4_100_0.010000_0.000667_0.000000.txt >> ../Plots/stampede_multi_nomad_hugewiki_all_4_100_0.010000_0.000667_0.000000.txt
done

rm ../Plots/stampede_multi_nomad_netflix_all_4_100_0.050000_0.008000_0.010000.txt
rm ../Plots/stampede_multi_nomad_yahoo_all_4_100_1.000000_0.000500_0.050000.txt
for i in 1 2 4 8 16 32 
do
    grep testgrep ../Results/stampede_multi_nomad_netflix_${i}_4_100_0.050000_0.008000_0.010000.txt | sort -t, -k2,2 -k4,4 -n > ../Plots/stampede_multi_nomad_netflix_${i}_4_100_0.050000_0.008000_0.010000.txt
    grep testgrep ../Results/stampede_multi_nomad_netflix_${i}_4_100_0.050000_0.008000_0.010000.txt | sort -t, -k2,2 -k4,4 -n >> ../Plots/stampede_multi_nomad_netflix_all_4_100_0.050000_0.008000_0.010000.txt
    grep testgrep ../Results/stampede_multi_nomad_yahoo_${i}_4_100_1.000000_0.000500_0.050000.txt | sort -t, -k2,2 -k4,4 -n > ../Plots/stampede_multi_nomad_yahoo_${i}_4_100_1.000000_0.000500_0.050000.txt
    grep testgrep ../Results/stampede_multi_nomad_yahoo_${i}_4_100_1.000000_0.000500_0.050000.txt | sort -t, -k2,2 -k4,4 -n >> ../Plots/stampede_multi_nomad_yahoo_all_4_100_1.000000_0.000500_0.050000.txt
done

# DSGD
grep iter ../Results/stampede_multi_dsgd_bold_wor_netflix_32_4_100_0.050000_0.008000_0.500000.txt | cut -d' ' -f4,16 > ../Plots/stampede_multi_dsgd_bold_wor_netflix_32_4_100_0.050000_0.008000_0.500000.txt
grep iter ../Results/stampede_multi_dsgd_bold_wor_yahoo_32_4_100_1.000000_0.000500_0.500000.txt | cut -d' ' -f4,16 > ../Plots/stampede_multi_dsgd_bold_wor_yahoo_32_4_100_1.000000_0.000500_0.500000.txt
grep iter ../Results/stampede_multi_dsgd_bold_wor_hugewiki_64_4_100_0.010000_0.008000_0.500000.txt | cut -d' ' -f4,16 > ../Plots/stampede_multi_dsgd_bold_wor_hugewiki_64_4_100_0.010000_0.008000_0.500000.txt

# ccd
grep iter ../Results/stampede_multi_ccdpp_netflix_32_4_100_0.050000.txt | cut -d' ' -f6,20 > ../Plots/stampede_multi_ccdpp_netflix_32_4_100_0.050000.txt
grep iter ../Results/stampede_multi_ccdpp_yahoo_32_4_100_1.000000.txt | cut -d' ' -f6,20 > ../Plots/stampede_multi_ccdpp_yahoo_32_4_100_1.000000.txt
grep iter ../Results/stampede_multi_ccdpp_hugewiki_64_4_100_0.010000.txt | cut -d' ' -f6,20 > ../Plots/stampede_multi_ccdpp_hugewiki_64_4_100_0.010000.txt


# 4.5 Scaling as both Dataset Size and Number of Machines grows

# nomad

for i in 4 16 32
do
    grep testgrep ../Results/stampede_synth_nomad_synth_${i}_4_100_0.010000_0.000800_0.000100.txt > ../Plots/stampede_synth_nomad_synth_${i}_4_100_0.010000_0.000800_0.000100.txt
done

# ccd
for i in 4 16 32
do
    grep iter ../Results/stampede_synth_ccdpp_${i}_4_100_0.010000.txt | cut -d' ' -f6,20 | head -5000 > ../Plots/stampede_synth_ccdpp_${i}_4_100_0.010000.txt 
done

# DSGD
for i in 4 16 32
do
    grep iter ../Results/stampede_synth_dsgd_bold_wor_${i}_4_100_0.010000_0.002000_0.500000.txt | cut -d' ' -f4,16 > ../Plots/stampede_synth_dsgd_bold_wor_${i}_4_100_0.010000_0.002000_0.500000.txt
done

# Appendix B. Effect of the Regularization Parameter

# netflix
for reg in 0.012500 0.025000 0.100000 0.200000
do
    grep testgrep ../Results/stampede_varyreg_nomad_netflix_32_4_100_${reg}_0.008000_0.010000.txt > ../Plots/stampede_varyreg_nomad_netflix_32_4_100_${reg}_
    grep iter ../Results/stampede_varyreg_dsgd_bold_wor_netflix_32_4_100_${reg}_0.008000_0.500000.txt | cut -d' ' -f4,16 > ../Plots/stampede_varyreg_dsgd_bo
    grep iter ../Results/stampede_varyreg_ccdpp_netflix_32_4_100_${reg}.txt | cut -d' ' -f6,22 | head -500 > ../Plots/stampede_varyreg_ccdpp_netflix_32_4_10
done

# yahoo
for reg in 0.250000 0.500000 2.000000 4.000000
do
    grep testgrep ../Results/stampede_varyreg_nomad_yahoo_32_4_100_${reg}_0.000500_0.050000.txt > ../Plots/stampede_varyreg_nomad_yahoo_32_4_100_${reg}_0.00
    grep iter ../Results/stampede_varyreg_dsgd_bold_wor_yahoo_32_4_100_${reg}_0.000500_0.500000.txt | cut -d' ' -f4,16 > ../Plots/stampede_varyreg_dsgd_bold
    grep iter ../Results/stampede_varyreg_ccdpp_yahoo_32_4_100_${reg}.txt | cut -d' ' -f6,22 | head -500 > ../Plots/stampede_varyreg_ccdpp_yahoo_32_4_100_${
done

# hugewiki
for reg in 0.002500 0.005000 0.020000 0.040000
do
    grep testgrep ../Results/stampede_varyreg_nomad_hugewiki_64_4_100_${reg}_0.000667_0.000000.txt > ../Plots/stampede_varyreg_nomad_hugewiki_64_4_100_${reg
    grep iter ../Results/stampede_varyreg_dsgd_bold_wor_hugewiki_64_4_100_${reg}_0.008000_0.500000.txt | cut -d' ' -f4,16 > ../Plots/stampede_varyreg_dsgd_b
    grep iter ../Results/stampede_varyreg_ccdpp_hugewiki_64_4_100_${reg}.txt | cut -d' ' -f6,22 | head -500 > ../Plots/stampede_varyreg_ccdpp_hugewiki_64_4_
done

# Appendix C. Effect of Latent Dimension

for  i in 10 20 50 100
do
    grep testgrep ../Results/stampede_varydim_nomad_netflix_8_4_${i}_0.050000_0.008000_0.010000.txt > ../Plots/stampede_varydim_nomad_netflix_8_4_${i}_1.000000_0.008000_0.010000.txt
    grep testgrep ../Results/stampede_varydim_nomad_yahoo_8_4_${i}_1.000000_0.008000_0.500000.txt > ../Plots/stampede_varydim_nomad_yahoo_8_4_${i}_1.000000_0.008000_0.500000.txt
    grep testgrep ../Results/stampede_varydim_nomad_hugewiki_8_4_${i}_0.010000_0.000667_0.000000.txt > ../Plots/stampede_varydim_nomad_hugewiki_8_4_${i}_0.010000_0.000667_0.000000.txt
done


