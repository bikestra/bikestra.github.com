for i in 4 16 32
do
    awk 'BEGIN {srand()} !/^$/ { if (rand() <= .01) print $0}' ../Plots/stampede_synth_nomad_synth_${i}_4_100_0.010000_0.002000_0.000100.txt > ../Plots/stampede_synth_nomad_synth_${i}_4_100_0.010000_0.002000_0.000100_sampled.txt
done