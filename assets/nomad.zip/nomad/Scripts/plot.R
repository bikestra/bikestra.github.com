library(lattice)
library(plyr)


df <- read.csv("../Results/stam_proc_hugewikiperm.txt", header=FALSE)
colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
df <- df[order(df$timeout),]
pdf("temp1.pdf")
xyplot(testrmse ~ timeout * numprocs, data=df, groups = numprocs, type="b", auto.key=TRUE, xlim=c(0,10000))
dev.off()

df$throughput = df$numupdates/df$timeout/df$numprocs/df$numcpus
write.table(df[df$timeout>100,c("numprocs","throughput")], file="../Results/stam_proc_hugewiki_throughput.txt", sep=" ",
            row.names=F, col.names=F, quote=F)
xyplot(numupdates/numprocs/timeout ~ numprocs, data=df, groups = numprocs, type="b", auto.key=TRUE, subset=timeout>100)


xyplot(numupdates/timeout/numprocs/numcpus ~ numprocs, data=df, groups = numprocs, type="b",
       auto.key=TRUE, subset=timeout > 200, ylim=c(0,2800000))
xyplot(numupdates/timeout/numprocs/numcpus ~ numprocs, data=df, groups = numprocs, type="b",
       auto.key=TRUE, ylim=c(0,2800000))

df$s.timeout <- df$timeout * df$numprocs

for (numproc in unique(df$numprocs)) {
  tempdf = data.frame(df[df$numprocs == numproc, c("s.timeout", "testrmse","timeout")])
  write.table(tempdf, file=paste("../Results/stam_proc_hugewiki_", numproc, ".txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)

  tempdf = data.frame(df[df$numprocs == numproc, c("numupdates", "testrmse")])
  write.table(tempdf, file=paste("../Results/stam_proc_hugewiki_", numproc, "_up.txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)

}

goal <- 0.57

pvvv <- ddply(df, .(numprocs), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$timeout[i1]
  x2 <- dd$timeout[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

pvvv$scale = pvvv$V1[1] / pvvv$V1 * 8
plot(pvvv$numprocs, pvvv$scale, type="b", xlim=c(0,64),ylim=c(0,124))
abline(a=0,b=1,col="red")
write.table(pvvv[,c("numprocs","scale")], file=paste("../Results/stam_proc_hugewiki_scale.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)

goal <- 0.57

pvvv <- ddply(df, .(numprocs), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$numupdates[i1]
  x2 <- dd$numupdates[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

pvvv$scale = pvvv$V1[1] / pvvv$V1
plot(pvvv$numprocs, pvvv$V1, type="b")
write.table(pvvv[,c("numprocs","V1")], file=paste("../Results/stam_proc_hugewiki_upscale.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)







df <- read.csv("../Results/stam_proc_hugewiki.txt", header=FALSE)
colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
df <- df[order(df$timeout),]
pdf("temp1.pdf")
xyplot(testrmse ~ timeout * numprocs, data=df, groups = numprocs, type="b", auto.key=TRUE)
dev.off()



df2 <- read.csv("../Results/stam_proc_hugewiki2.txt", header=FALSE)
colnames(df2) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
df2 <- df2[order(df2$timeout),]
pdf("temp2.pdf")
xyplot(testrmse ~ timeout * numprocs, data=df2, groups = numprocs, type="b", auto.key=TRUE)
dev.off()



df$s.timeout <- df$timeout * df$numprocs

for (numproc in unique(df$numprocs)) {
  tempdf = data.frame(df[df$numprocs == numproc, c("s.timeout", "testrmse", "timeout")])
  write.table(tempdf, file=paste("stam_proc_netflix_", numproc, ".txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)

  tempdf = data.frame(df[df$numprocs == numproc, c("numupdates", "testrmse")])
  write.table(tempdf, file=paste("stam_proc_netflix_", numproc, "_up.txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)

}

goal <- 0.92

pvvv <- ddply(df, .(numprocs), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$timeout[i1]
  x2 <- dd$timeout[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

pvvv$scale = pvvv$V1[1] / pvvv$V1
plot(pvvv$numprocs, pvvv$scale, type="b")
write.table(pvvv[,c("numprocs","scale")], file=paste("stam_proc_netflix_scale.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)







df <- read.csv("scale_yahoo.txt", header=FALSE)
colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")

df <- df[order(df$timeout),]

xyplot(numupdates/timeout/numcpus/numprocs ~ numprocs | numcpus, data=df, groups=numprocs, type="b",
       ylim=c(0, 1500000))

xyplot(testrmse ~ timeout * numcpus * numprocs | numcpus, data=df, groups=numprocs, type="b",
       auto.key=TRUE)

pdf <- read.csv("priority_yahoo.txt", header=FALSE)
colnames(pdf) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b", "numfail", "emptynum", "numsend")
pdf <- pdf[order(pdf$timeout),]


qdf <- read.csv("realp.txt", header=FALSE)
colnames(qdf) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b", "numfail", "emptynum", "numsend")
qdf <- qdf[order(qdf$timeout),]

xyplot(numupdates/timeout/numcpus/numprocs ~ numprocs | numcpus, data=qdf, groups=numprocs, type="b",
       ylim=c(0, 1500000))

xyplot(testrmse ~ timeout * numcpus * numprocs | numcpus, data=qdf, groups=numprocs, type="b",
       auto.key=TRUE)

pdf$ptype = "normal"
qdf$ptype = "priority"

comb <- rbind(pdf[pdf$numcpus==4,], qdf[qdf$numcpus==4,])

xyplot(numupdates/timeout/numcpus/numprocs ~ numprocs | numcpus, data=comb, groups=ptype,
       ylim=c(0, 1500000), auto.key=TRUE)

xyplot(testrmse ~ timeout * numcpus * numprocs | numprocs, data=comb, groups=ptype, type="b",
       auto.key=TRUE)

pdf$stime <- pdf$timeout * pdf$numprocs
write.table(subset(pdf, numcpus == 4 & numprocs == 1)[,c(13,6)], file='~/Research/bigml/talk/yahoo_1.txt', row.names=FALSE, col.names=FALSE)
write.table(subset(pdf, numcpus == 4 & numprocs == 2)[,c(13,6)], file='~/Research/bigml/talk/yahoo_2.txt', row.names=FALSE, col.names=FALSE)
write.table(subset(pdf, numcpus == 4 & numprocs == 4)[,c(13,6)], file='~/Research/bigml/talk/yahoo_4.txt', row.names=FALSE, col.names=FALSE)
write.table(subset(pdf, numcpus == 4 & numprocs == 8)[,c(13,6)], file='~/Research/bigml/talk/yahoo_8.txt', row.names=FALSE, col.names=FALSE)
write.table(subset(pdf, numcpus == 4 & numprocs == 12)[,c(13,6)], file='~/Research/bigml/talk/yahoo_12.txt', row.names=FALSE, col.names=FALSE)
write.table(subset(pdf, numcpus == 4 & numprocs == 16)[,c(13,6)], file='~/Research/bigml/talk/yahoo_16.txt', row.names=FALSE, col.names=FALSE)

?write.table

pdf("priority1.pdf")
xyplot(numupdates/timeout/numcpus/numprocs ~ numprocs | numcpus, data=pdf, groups=numprocs, type="b",
       ylim=c(0, 1500000))
dev.off()

pdf("before1.pdf")
xyplot(numupdates/timeout/numcpus/numprocs ~ numprocs | numcpus, data=df, groups=numprocs, type="b",
       ylim=c(0, 1500000))
dev.off()



pdf("priority2.pdf")
xyplot(testrmse ~ timeout * numcpus * numprocs | numcpus, data=pdf, groups=numprocs, type="b",
       auto.key=TRUE)
dev.off()

pdf$ptype = "priority"
df$ptype = "none"

vnp12cpu4 <- rbind(pdf[pdf$numcpus == 4,c(1:6,12)], df[df$numcpus == 4,c(1:6,9)])
pdf("priority3.pdf")
xyplot(testrmse ~ timeout * numcpus * numprocs | numprocs, data=vnp12cpu4, groups=ptype, type="b", auto.key=TRUE)
dev.off()
pdf("priority4.pdf")
xyplot(numupdates ~ timeout * numcpus * numprocs | numprocs, data=vnp12cpu4, groups=ptype, type="b", auto.key=TRUE)
dev.off()




pdf4 <- pdf[pdf$numcpus == 4,]

goal <- 20.0

pvvv <- ddply(pdf4, .(numprocs), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$timeout[i1]
  x2 <- dd$timeout[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

plot(pvvv$numprocs, pvvv$V1[1] / pvvv$V1, type="b")

pvvv$speedup <- pvvv$V1[1] / pvvv$V1
write.table(pvvv[,c(1,3)], file='~/Research/bigml/talk/yahoo_scale.txt', row.names=FALSE, col.names=FALSE)


plot(vvv$numprocs, vvv$V1[1] / vvv$V1, type="b")
abline(a=0, b=1, col="red")


# xyplot(numsend ~ timeout * numcpus * numprocs | numprocs, data=pdf, subset=numcpus==4)


df4 <- df[df$numcpus == 4,]

goal <- 20.4

vvv <- ddply(df4, .(numprocs), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$timeout[i1]
  x2 <- dd$timeout[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

pdf("priority5.pdf")
plot(vvv$numprocs, vvv$V1, type="b", ylim=c(0,5000), ylab="time to 20.4")
points(pvvv$numprocs, pvvv$V1, col="red")
lines(pvvv$numprocs, pvvv$V1, col="red")
dev.off()

pdf("priority6.pdf")
plot(vvv$numprocs, vvv$V1[1] / vvv$V1, type="b", ylim=c(0,40), main="speedup versus non-priority 1 machine")
points(pvvv$numprocs, vvv$V1[1] / pvvv$V1, col="red")
lines(pvvv$numprocs, vvv$V1[1] / pvvv$V1, col="red")
dev.off()

pdf("priority7.pdf")
plot(vvv$numprocs, pvvv$V1[1] / vvv$V1, type="b", ylim=c(0,40), main="speedup versus priority 1 machine")
points(pvvv$numprocs, pvvv$V1[1] / pvvv$V1, col="red")
lines(pvvv$numprocs, pvvv$V1[1] / pvvv$V1, col="red")
dev.off()



abline(a=0, b=1, col="red")



xyplot(numupdates/timeout/numcpus/numprocs ~ numprocs | numcpus, data=df, groups=numprocs, type="b",
       ylim=c(0, 1500000))

xyplot(numupdates/timeout/numcpus ~ numprocs | numcpus, data=df, groups=numprocs, type="b"
       )


xyplot(testrmse ~ timeout * numcpus * numprocs | numcpus, data=df, groups=numprocs, type="b",
       auto.key=TRUE)

xyplot(numupdates/timeout/numcpus/numprocs ~ numcpus | numprocs, data=df, groups=numcpus, type="b",
       ylim=c(0, 1500000))

xyplot(testrmse ~ timeout * numcpus * numprocs | numprocs, data=df, groups=numcpus, type="b",
       auto.key=TRUE)


vvv$speedup <- vvv$V1[1] / vvv$V1

write.table(vvv[,c("numprocs", "speedup")], file = "./temp.txt", quote=FALSE, col.names=FALSE)





pdf("newscale1.pdf")
xyplot(numupdates/timeout/numcpus/numprocs ~ numprocs | numcpus, data=df, groups=numprocs, type="b",
       scale=list(x="free", y="free"), ylim=c(0, 1500000))
dev.off()

xyplot(numupdates/timeout/numcpus/numprocs ~ numprocs | numcpus, data=df, groups=numprocs, type="b",
       ylim=c(0,1500000), subset=numcpus < 12 & numprocs <= 8)


pdf("newscale2.pdf")
xyplot(testrmse ~ timeout * numcpus * numprocs | numcpus, data=df, groups=numprocs, type="b",
       scale=list(x="free", y="free"), auto.key=TRUE)
dev.off()

xyplot(testrmse ~ timeout * numcpus * numprocs | numcpus, data=df, groups=numprocs, type="b",
       auto.key=TRUE)


pdf("newscale3.pdf")
xyplot(numupdates/timeout ~ numcpus | factor(numprocs), data=df, groups=numcpus, type="b",
       scale=list(x="free", y="free"),auto.key=TRUE)
dev.off()

pdf("newscale4.pdf")
xyplot(testrmse ~ timeout * numcpus * numprocs | numprocs, data=df, groups=numcpus, type="b",
       scale=list(x="free", y="free"), auto.key=TRUE)
dev.off()



df$numprocs


df2 <- read.csv("double.txt", header=FALSE)
colnames(df2) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse")

par(mfrow=c(1,2))
plot(df2$numcpus, df2$numupdates/df2$timeout/df2$numcpus, ylim=c(0,1600000))
plot(df2$numcpus, df2$numupdates/df2$timeout, ylim=c(9,40000000))
xs <- 1:20
lines(xs, 1550326570/1000.0 * xs, col="red")
plot(xs, 1550326570/1000.0 * xs, col="red")


xyplot(numupdates/timeout/numcpus ~ numcpus, data=df2, ylim=c(0,1600000))
xyplot(numupdates/timeout ~ numcpus, data=df2)
      
library(plyr)





df <- read.csv("scale_netflix.txt", header=FALSE)
colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")

df <- df[order(df$timeout),]

xyplot(numupdates/timeout/numcpus/numprocs ~ numprocs | numcpus, data=df, groups=numprocs, type="b",
       ylim=c(0, 1500000))

xyplot(testrmse ~ timeout * numcpus * numprocs | numcpus, data=df, groups=numprocs, type="b",
       auto.key=TRUE)

xyplot(numupdates/timeout/numcpus/numprocs ~ numcpus | numprocs, data=df, groups=numcpus, type="b",
       ylim=c(0, 1500000))

xyplot(testrmse ~ timeout * numcpus * numprocs | numprocs, data=df, groups=numcpus, type="b",
       auto.key=TRUE)


df4 <- df[df$numcpus == 4,]

goal <- 0.88

vvv <- ddply(df4, .(numprocs), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$timeout[i1]
  x2 <- dd$timeout[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

plot(vvv$numprocs, vvv$V1[1] / vvv$V1, type="b")
abline(a=0, b=1, col="red")

vvv$speedup <- vvv$V1[1] / vvv$V1

write.table(vvv[,c("numprocs", "speedup")], file = "~/Research/bigml/talk/netflix_scale.txt", quote=FALSE, row.names=FALSE, col.names=FALSE)

write.table(vvv[,c("numprocs", "speedup")], file = "./temp.txt", quote=FALSE, col.names=FALSE)



ddd <- read.csv("starve.txt", header=FALSE)
colnames(ddd) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b", "numfail")
pdf("starve3.pdf")
xyplot(numfail ~ numprocs, data=ddd, ylab="number of pop failures")
dev.off()
pdf("starve4.pdf")
xyplot(numupdates ~ numprocs, data=ddd, ylab="number of updates")
dev.off()

par(mfrow=c(1,2))
plot(ddd$numprocs, ddd$numupdates)
plot(ddd$numprocs, ddd$numfail)



eee <- read.csv("starve3_np12_cpu8_0.txt", header=FALSE)
head(eee)
colnames(eee) <- c("dummy", "index", "time", "size")
eee$size


max(eee$time)

eeee <- ddply(eee, .(time), summarize, tt=sum(size))
plot(eeee$time, eeee$tt, type="l")

eeeef <- data.frame(dummy="haha", index=20, time=eeee$time, size=eeee$tt)

finale <- rbind(eeeef, eee)

pdf("starve1.pdf")
pdf("new_starve_np12.pdf")
pdf("new_starve_np12_cpu8.pdf")
xyplot(size ~ time, groups=index, data=eee, type="l", main="20 machines")
dev.off()

pdf("starve2_2.pdf")
pdf("new_starve2.pdf")
xyplot(size ~ time, groups=index, data=finale, type="l", main="20 machines with sum")
dev.off()




eee2 <- read.csv("starve2_12.txt", header=FALSE)
colnames(eee2) <- c("dummy", "index", "time", "size")

eeee2 <- ddply(eee2, .(time), summarize, tt=sum(size))

eeeef2 <- data.frame(dummy="haha", index=12, time=eeee2$time, size=eeee2$tt)

finale2 <- rbind(eeeef2, eee2)

pdf("starve1_2.pdf")
xyplot(size ~ time, groups=index, data=eee2, type="l", main="12 machines")
dev.off()

pdf("starve2_2.pdf")
xyplot(size ~ time, groups=index, data=finale2, type="l", main="12 machines")
dev.off()







eee <- read.csv("bound_np20_cpu4_0.txt", header=FALSE)
head(eee)
colnames(eee) <- c("dummy", "index", "time", "size")

eeee <- ddply(eee, .(time), summarize, tt=sum(size))
plot(eeee$time, eeee$tt, type="l")

eeeef <- data.frame(dummy="haha", index=20, time=eeee$time, size=eeee$tt)

finale <- rbind(eeeef, eee)

xyplot(size ~ time, groups=index, data=eee, type="l", main="20 machines")
pdf("bound.pdf")
xyplot(size ~ time, groups=index, data=finale, type="l", main="20 machines with sum")
dev.off()







df <- read.csv("stampede_scale_yahoo.txt", header=FALSE)
colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")

df <- df[order(df$timeout),]
xyplot(numupdates/timeout/numcpus/numprocs ~ numprocs | numcpus, data=df, groups=numprocs, type="b")

xyplot(testrmse ~ timeout * numcpus * numprocs | numcpus, data=df, groups=numprocs, type="b",
       auto.key=TRUE)

df4 <- df[df$numcpus == 4,]

goal <- 20.4

vvv <- ddply(df4, .(numprocs), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$timeout[i1]
  x2 <- dd$timeout[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

pdf("priority5.pdf")
plot(vvv$numprocs, vvv$V1, type="b", ylim=c(0,5000), ylab="time to 20.4")
points(pvvv$numprocs, pvvv$V1, col="red")
lines(pvvv$numprocs, pvvv$V1, col="red")
dev.off()


plot(vvv$numprocs, vvv$V1[1] / vvv$V1, type="b")
abline(a=0,b=1,col="red")


pdf4 = pdf[pdf$numcpus == 4,]

pdf4$mach = "rossmann"
df$mach = "stampede"
ddf <- rbind(pdf4[,c("numprocs","numupdates","mach","timeout")], df[,c("numprocs","numupdates","mach","timeout")])

xyplot(numupdates/timeout ~ numprocs, groups=mach, data=ddf, auto.key=TRUE)




pdf <- read.csv("priority_yahoo.txt", header=FALSE)
colnames(pdf) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b", "numfail", "emptynum", "numsend")
pdf <- pdf[order(pdf$timeout),]

mdf <- read.csv("mvapich2.txt", header=FALSE)
colnames(mdf) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b", "numfail", "emptynum", "numsend")
mdf <- mdf[order(mdf$timeout),]


odf <- read.csv("scale_yahoo.txt", header=FALSE)
colnames(odf) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
odf <- odf[order(odf$timeout),]
odf$numfail = 0
odf$emptynum = 0
odf$numsend = 0

pdf4 <- pdf[pdf$numcpus == 4,]
mdf4 <- mdf[mdf$numcpus == 4,]
odf4 <- odf[odf$numcpus == 4,]

pdf4$mpi = "mpich2"
mdf4$mpi = "mvapich2"
odf4$mpi = "old"

pmdf4 <- rbind(pdf4, mdf4, odf4)
xyplot(numupdates/numprocs/timeout ~ numprocs, groups=mpi, data=pmdf4, auto.key=TRUE)



df <- read.csv("../Results/stam_proc_netflix.txt", header=FALSE)

colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
df <- df[order(df$timeout),]
xyplot(testrmse ~ timeout * numprocs, data=df, groups = numprocs, type="b", auto.key=TRUE)
xyplot(testrmse ~ numupdates, data=df, groups = numprocs, type="b", auto.key=TRUE, ylim=c(0.91,0.95))

df$throughput = df$numupdates/df$timeout/df$numprocs/df$numcpus
write.table(df[df$timeout>100,c("numprocs","throughput")], file="../Results/stam_proc_netflix_throughput.txt", sep=" ",
            row.names=F, col.names=F, quote=F)
xyplot(numupdates/numprocs/timeout ~ numprocs, data=df, groups = numprocs, type="b", auto.key=TRUE, subset=timeout>100)

df$s.timeout <- df$timeout * df$numprocs

for (numproc in unique(df$numprocs)) {
  tempdf = data.frame(df[df$numprocs == numproc, c("s.timeout", "testrmse", "timeout")])
  write.table(tempdf, file=paste("../Results/stam_proc_netflix_", numproc, ".txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)

  tempdf = data.frame(df[df$numprocs == numproc, c("numupdates", "testrmse")])
  write.table(tempdf, file=paste("../Results/stam_proc_netflix_", numproc, "_up.txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)
}

goal <- 0.92

pvvv <- ddply(df, .(numprocs), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$timeout[i1]
  x2 <- dd$timeout[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

pvvv$scale = pvvv$V1[1] / pvvv$V1
plot(pvvv$numprocs, pvvv$scale, type="b")
write.table(pvvv[,c("numprocs","scale")], file=paste("stam_proc_netflix_scale.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)

goal <- 0.92

pvvv <- ddply(df, .(numprocs), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$numupdates[i1]
  x2 <- dd$numupdates[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

plot(pvvv$numprocs, pvvv$V1, type="b")
write.table(pvvv[,c("numprocs","V1")], file=paste("../Results/stam_proc_netflix_upscale.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)



pvvv$scale = pvvv$V1[1] / pvvv$V1
plot(pvvv$numprocs, pvvv$scale, type="b")





df <- read.csv("../Results/stam_proc_yahoo.txt", header=FALSE)

colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
df <- df[order(df$timeout),]
xyplot(testrmse ~ timeout * numprocs, data=df, groups = numprocs, type="b", auto.key=TRUE, ylim=c(20,25))
xyplot(numupdates/timeout/numprocs ~ numprocs, data=df, groups = numprocs, type="b", auto.key=TRUE, subset=timeout > 100)

df$throughput = df$numupdates/df$timeout/df$numprocs/df$numcpus
write.table(df[df$timeout > 100,c("numprocs","throughput")], file="../Results/stam_proc_yahoo_throughput.txt", sep=" ",
            row.names=F, col.names=F, quote=F)


df$s.timeout <- df$timeout * df$numprocs

for (numproc in unique(df$numprocs)) {
  tempdf = data.frame(df[df$numprocs == numproc, c("s.timeout", "testrmse", "timeout")])
  write.table(tempdf, file=paste("../Results/stam_proc_yahoo_", numproc, ".txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)

  tempdf = data.frame(df[df$numprocs == numproc, c("numupdates", "testrmse")])
  write.table(tempdf, file=paste("../Results/stam_proc_yahoo_", numproc, "_up.txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)

}

goal <- 22.5

pvvv <- ddply(df, .(numprocs), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$timeout[i1]
  x2 <- dd$timeout[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

pvvv$scale = pvvv$V1[1] / pvvv$V1
plot(pvvv$numprocs, pvvv$scale, type="b")
write.table(pvvv[,c("numprocs","scale")], file=paste("stam_proc_yahoo_scale.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)

goal <- 22.5

pvvv <- ddply(df, .(numprocs), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$numupdates[i1]
  x2 <- dd$numupdates[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

pvvv$scale = pvvv$V1[1] / pvvv$V1
plot(pvvv$numprocs, pvvv$V1, type="b")
write.table(pvvv[,c("numprocs","V1")], file=paste("../Results/stam_proc_yahoo_upscale.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)




lin001 <- read.fwf("../Results/cjlin_netflix_001.txt", header=FALSE, widths=c(8,12,8))
lin002 <- read.fwf("../Results/cjlin_netflix_002.txt", header=FALSE, widths=c(8,12,8))
lin004 <- read.fwf("../Results/cjlin_netflix_004.txt", header=FALSE, widths=c(8,12,8))
lin008 <- read.fwf("../Results/cjlin_netflix_008.txt", header=FALSE, widths=c(8,12,8))
lin016 <- read.fwf("../Results/cjlin_netflix_016.txt", header=FALSE, widths=c(8,12,8))
lin001$step = 0.001
lin002$step = 0.002
lin004$step = 0.004
lin008$step = 0.008
lin016$step = 0.016
lins <- rbind(lin001, lin002, lin004, lin008, lin016)

ross <- read.csv("../Results/ross_netflix_compare.txt", header=FALSE)
ross$step = "nomad"
partross <- ross[,c("V4", "V6", "step")]
colnames(partross) <- c("time", "rmse", "step")
partlins <- lins[,2:4]
colnames(partlins) <- c("time", "rmse", "step")

pdf("cjlin.pdf")
xyplot(V3 ~ V2 | factor(step), data=lins, type="l", auto.key=TRUE,
       panel=function(x,y, ...) {
         panel.xyplot(x,y, ...)
         panel.xyplot(partross$time, partross$rmse, col="red", type="b")
       }, ylim=c(0.9, 1.1))
dev.off()


parts <- rbind(partross, partlins)
xyplot(rmse ~ time, data=parts, group=step, type="l", auto.key=TRUE) 


df <- read.csv("../Results/merge_cpus_netflix.txt", header=FALSE)
colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
xyplot(testrmse ~ timeout * numprocs * numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout ~ numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout/numcpus ~ numcpus, data=df, groups = numcpus, auto.key=TRUE, ylim=c(0,4500000))

df$throughput = df$numupdates/df$timeout/df$numcpus
write.table(df[,c("numcpus","throughput")], file="../Results/stam_cpus_netflix_throughput.txt", sep=" ",
            row.names=F, col.names=F, quote=F)

df$s.timeout <- df$timeout * df$numcpus * df$numprocs
for (numcpu in unique(df$numcpus)) {
  print (numcpu)
  tempdf = data.frame(df[df$numcpus == numcpu, c("s.timeout", "testrmse", "timeout")])
  write.table(tempdf, file=paste("../Results/stam_cpus_netflix_", numcpu, ".txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)

  tempdf = data.frame(df[df$numcpus == numcpu, c("numupdates", "testrmse")])
  write.table(tempdf, file=paste("../Results/stam_cpus_netflix_", numcpu, "_up.txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)
}

goal <- 0.92

pvvv <- ddply(df, .(numcpus), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$timeout[i1]
  x2 <- dd$timeout[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

pvvv$scale = pvvv$V1[1] / pvvv$V1 * 4
plot(pvvv$numcpus, pvvv$scale, type="b")
write.table(pvvv[,c("numcpus","scale")], file=paste("../Results/stam_cpus_netflix_scale.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)

goal <- 0.92

pvvv <- ddply(df, .(numcpus), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$numupdates[i1]
  x2 <- dd$numupdates[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

plot(pvvv$numcpus, pvvv$V1, type="b")
write.table(pvvv[,c("numcpus","V1")], file=paste("../Results/stam_cpus_netflix_upscale.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)





df <- read.csv("../Results/float_cpus_yahoo.txt", header=FALSE)
colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
xyplot(testrmse ~ timeout * numprocs * numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE, ylim=c(20,30))
xyplot(numupdates/timeout ~ numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout/numcpus ~ numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)



df <- read.csv("../Results/merge_cpus_yahoo.txt", header=FALSE)
colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
xyplot(testrmse ~ timeout * numprocs * numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout ~ numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout/numcpus/numprocs ~ numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)

df$throughput = df$numupdates/df$timeout/df$numcpus
write.table(df[,c("numcpus","throughput")], file="../Results/stam_cpus_yahoo_throughput.txt", sep=" ",
            row.names=F, col.names=F, quote=F)


df$s.timeout <- df$timeout * df$numcpus * df$numprocs
for (numcpu in unique(df$numcpus)) {
  print (numcpu)
  tempdf = data.frame(df[df$numcpus == numcpu, c("s.timeout", "testrmse", "timeout")])
  write.table(tempdf, file=paste("../Results/stam_cpus_yahoo_", numcpu, ".txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)

  tempdf = data.frame(df[df$numcpus == numcpu, c("numupdates", "testrmse")])
  write.table(tempdf, file=paste("../Results/stam_cpus_yahoo_", numcpu, "_up.txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)
}

goal <- 22.5

pvvv <- ddply(df, .(numcpus), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$timeout[i1]
  x2 <- dd$timeout[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

pvvv$scale = pvvv$V1[1] / pvvv$V1 * 4
plot(pvvv$numcpus, pvvv$scale, type="b")
write.table(pvvv[,c("numcpus","scale")], file=paste("../Results/stam_cpus_yahoo_scale.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)

goal <- 22.5

pvvv <- ddply(df, .(numcpus), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$numupdates[i1]
  x2 <- dd$numupdates[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

plot(pvvv$numcpus, pvvv$V1, type="b")
write.table(pvvv[,c("numcpus","V1")], file=paste("../Results/stam_cpus_yahoo_upscale.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)







df <- read.csv("../Results/stam_cpus_netflix.txt", header=FALSE)
colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
df <- df[order(df$timeout),]
xyplot(testrmse ~ timeout * numprocs * numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout ~ numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout/numcpus ~ numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE, ylim=c(0,3200000))


fdf <- read.csv("../Results/float_cpus_netflix.txt", header=FALSE)
colnames(fdf) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
fdf <- fdf[order(fdf$timeout),]
xyplot(testrmse ~ timeout * numprocs * numcpus, data=fdf, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout ~ numcpus, data=fdf, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout/numcpus ~ numcpus, data=fdf, groups = numcpus, type="b", auto.key=TRUE)



df$type = "double"
fdf$type = "float"
dfs <- rbind(df, fdf)
xyplot(testrmse ~ timeout | numcpus, data=dfs, groups=type, type="b")

df <- fdf

df$s.timeout <- df$timeout * df$numprocs

for (numproc in unique(df$numprocs)) {
  tempdf = data.frame(df[df$numprocs == numproc, c("s.timeout", "testrmse", "timeout")])
  write.table(tempdf, file=paste("../Results/stam_proc_yahoo_", numproc, ".txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)

  tempdf = data.frame(df[df$numprocs == numproc, c("numupdates", "testrmse")])
  write.table(tempdf, file=paste("../Results/stam_proc_yahoo_", numproc, "_up.txt", sep=""), sep=" ",
              row.names=F, col.names=F, quote=F)

}


cjdfs <- c()

cjdf <- read.fwf("../Results/stam_cjlin_netflix_cpu4.txt", header=FALSE, widths=c(8,12,8,10))
colnames(cjdf) <- c("iter","s.timeout","trainrmse","testrmse")
cjdf$numcpus = 4
cjdfs <- rbind(cjdfs, cjdf)

cjdf <- read.fwf("../Results/stam_cjlin_netflix_cpu8.txt", header=FALSE, widths=c(8,12,8,10))
colnames(cjdf) <- c("iter","s.timeout","trainrmse","testrmse")
cjdf$numcpus = 8
cjdfs <- rbind(cjdfs, cjdf)

cjdf <- read.fwf("../Results/stam_cjlin_netflix_cpu12.txt", header=FALSE, widths=c(8,12,8,10))
colnames(cjdf) <- c("iter","s.timeout","trainrmse","testrmse")
cjdf$numcpus = 12
cjdfs <- rbind(cjdfs, cjdf)

cjdf <- read.fwf("../Results/stam_cjlin_netflix_cpu14.txt", header=FALSE, widths=c(8,12,8,10))
colnames(cjdf) <- c("iter","s.timeout","trainrmse","testrmse")
cjdf$numcpus = 14
cjdfs <- rbind(cjdfs, cjdf)

cjdf <- read.fwf("../Results/stam_cjlin_netflix_cpu16.txt", header=FALSE, widths=c(8,12,8,10))
colnames(cjdf) <- c("iter","s.timeout","trainrmse","testrmse")
cjdf$numcpus = 16
cjdfs <- rbind(cjdfs, cjdf)


cjdfs$timeout <- cjdfs$s.timeout / cjdfs$numcpus

xyplot(testrmse ~ timeout, data=cjdfs, groups=numcpus, auto.key=TRUE, type="l")
xyplot(testrmse ~ s.timeout, data=cjdfs, groups=numcpus, auto.key=TRUE, type="l")

cjdfs$method = "lin"
df$method = "nomad"
#df$timeout = df$timeout/2

tempdf <- rbind(df[,c("timeout", "testrmse", "method","numcpus")], cjdfs[, c("timeout", "testrmse", "method","numcpus")])
pdf("lin_vs_nomad_netflix.pdf")
xyplot(testrmse ~ timeout | factor(numcpus), data=tempdf, groups=method, auto.key=TRUE, type="l", xlim=c(0,200), main="netflix")
dev.off()

tempdf <- rbind(df[df$numcpus == 4,c("timeout", "testrmse", "method")], cjdfs[cjdfs$numcpus == 4, c("timeout", "testrmse", "method")])
xyplot(testrmse ~ timeout, data=tempdf, groups=method, auto.key=TRUE, type="l", xlim=c(0,300))

tempdf <- rbind(df[df$numcpus == 8,c("timeout", "testrmse", "method")], cjdfs[cjdfs$numcpus == 8, c("timeout", "testrmse", "method")])
xyplot(testrmse ~ timeout, data=tempdf, groups=method, auto.key=TRUE, type="l", xlim=c(0,150))

tempdf <- rbind(df[df$numcpus == 12,c("timeout", "testrmse", "method")], cjdfs[cjdfs$numcpus == 12, c("timeout", "testrmse", "method")])
xyplot(testrmse ~ timeout, data=tempdf, groups=method, auto.key=TRUE, type="l", xlim=c(0,100))

tempdf <- rbind(df[df$numcpus == 14,c("timeout", "testrmse", "method")], cjdfs[cjdfs$numcpus == 14, c("timeout", "testrmse", "method")])
xyplot(testrmse ~ timeout, data=tempdf, groups=method, auto.key=TRUE, type="l", xlim=c(0,80))




df <- read.csv("../Results/stam_cpus_yahoo.txt", header=FALSE)
colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
df <- df[order(df$timeout),]
xyplot(testrmse ~ timeout * numprocs * numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout ~ numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout/numcpus ~ numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE, ylim=c(0,3200000))

df <- read.csv("../Results/float_cpus_yahoo.txt", header=FALSE)
colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "a", "b")
df <- df[order(df$timeout),]
xyplot(testrmse ~ timeout * numprocs * numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout ~ numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)
xyplot(numupdates/timeout/numcpus ~ numcpus, data=df, groups = numcpus, type="b", auto.key=TRUE)

cjdfs <- c()

cjdf <- read.fwf("../Results/stam_cjlin_yahoo_cpu4.txt", header=FALSE, widths=c(7,13,8,10))
colnames(cjdf) <- c("iter","s.timeout","trainrmse","testrmse")
cjdf$numcpus = 4
cjdfs <- rbind(cjdfs, cjdf)

cjdf <- read.fwf("../Results/stam_cjlin_yahoo_cpu8.txt", header=FALSE, widths=c(7,13,8,10))
colnames(cjdf) <- c("iter","s.timeout","trainrmse","testrmse")
cjdf$numcpus = 8
cjdfs <- rbind(cjdfs, cjdf)

cjdf <- read.fwf("../Results/stam_cjlin_yahoo_cpu12.txt", header=FALSE, widths=c(7,13,8,10))
colnames(cjdf) <- c("iter","s.timeout","trainrmse","testrmse")
cjdf$numcpus = 12
cjdfs <- rbind(cjdfs, cjdf)

cjdf <- read.fwf("../Results/stam_cjlin_yahoo_cpu14.txt", header=FALSE, widths=c(7,13,8,10))
colnames(cjdf) <- c("iter","s.timeout","trainrmse","testrmse")
cjdf$numcpus = 14
cjdfs <- rbind(cjdfs, cjdf)

cjdfs$timeout <- cjdfs$s.timeout / cjdfs$numcpus
cjdfs <- cjdfs[order(cjdfs$timeout),]

xyplot(testrmse ~ timeout, data=cjdfs, groups=numcpus, auto.key=TRUE, type="l")
xyplot(testrmse ~ s.timeout, data=cjdfs, groups=numcpus, auto.key=TRUE, type="l")

cjdfs$method = "lin"
df$method = "nomad"

tempdf <- rbind(df[,c("timeout", "testrmse", "method","numcpus")], cjdfs[, c("timeout", "testrmse", "method","numcpus")])
pdf("lin_vs_nomad_yahoo.pdf")
xyplot(testrmse ~ timeout|factor(numcpus), data=tempdf, groups=method, auto.key=TRUE, type="l", xlim=c(0,300), main="yahoo")
dev.off()



cjdf <- read.fwf("../Results/largelin_netflix_cpu24.txt", header=FALSE, widths=c(7,12,7))
colnames(cjdf) <- c("iter","s.timeout","testrmse")
plot(cjdf$s.timeout, cjdf$testrmse)
cjdf$timeout = cjdf$s.timeout / 24
write.table(cjdf[,c("timeout","testrmse")], file=paste("../Results/largelin_netflix_cpu24_formatted.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)


cjdf <- read.fwf("../Results/largelin_yahoo_cpu24.txt", header=FALSE, widths=c(7,12,7))
colnames(cjdf) <- c("iter","s.timeout","testrmse")
plot(cjdf$s.timeout, cjdf$testrmse)
cjdf$timeout = cjdf$s.timeout / 24
write.table(cjdf[,c("timeout","testrmse")], file=paste("../Results/largelin_yahoo_cpu24_formatted.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)

cjdf <- read.fwf("../Results/largelin_yahoo_cpu30.txt", header=FALSE, widths=c(7,12,7))
colnames(cjdf) <- c("iter","s.timeout","testrmse")
plot(cjdf$s.timeout, cjdf$testrmse)
cjdf$timeout = cjdf$s.timeout / 30
write.table(cjdf[,c("timeout","testrmse")], file=paste("../Results/largelin_yahoo_cpu30_formatted.txt", sep=""), sep=" ",
            row.names=F, col.names=F, quote=F)


numprocs <- c(8,16,32,64)
hopdfs <- c()
for (numproc in numprocs) {
  filename = paste("../Results/dsgd_hugewiki_", numproc, ".txt", sep="")
  print(filename)
  tempdf <- read.csv(filename, sep=" ", header=FALSE)
  colnames(tempdf) <- c("numprocs","timeout","testrmse")
  hopdf <- data.frame(numprocs=numproc, throughput=(1:nrow(tempdf) * 2736496604)/tempdf$timeout/numproc)
  hopdfs <- rbind(hopdfs, hopdf)
}
write.table(hopdfs, file="../Results/dsgd_hugewiki_throughput.txt", sep=" ",
            row.names=F, col.names=F, quote=F)


numprocs <- c(1,2,4,8,16,32)
hopdfs <- c()
for (numproc in numprocs) {
  filename = paste("../Results/dsgd_netflix_", numproc, ".txt", sep="")
  print(filename)
  tempdf <- read.csv(filename, sep=" ", header=FALSE)
  colnames(tempdf) <- c("numprocs","timeout","testrmse")
  hopdf <- data.frame(numprocs=numproc, throughput=(1:nrow(tempdf) * 99072112)/tempdf$timeout/numproc)
  hopdfs <- rbind(hopdfs, hopdf)
}
write.table(hopdfs, file="../Results/dsgd_netflix_throughput.txt", sep=" ",
            row.names=F, col.names=F, quote=F)

numprocs <- c(1,2,4,8,16,32)
hopdfs <- c()
for (numproc in numprocs) {
  filename = paste("../Results/dsgd_yahoo_", numproc, ".txt", sep="")
  print(filename)
  tempdf <- read.csv(filename, sep=" ", header=FALSE)
  colnames(tempdf) <- c("numprocs","timeout","testrmse")
  hopdf <- data.frame(numprocs=numproc, throughput=(1:nrow(tempdf) * 252800275)/tempdf$timeout/numproc)
  hopdfs <- rbind(hopdfs, hopdf)
}
write.table(hopdfs, file="../Results/dsgd_yahoo_throughput.txt", sep=" ",
            row.names=F, col.names=F, quote=F)
