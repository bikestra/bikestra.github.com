library(lattice)
library(plyr)

dataname <- "hugewiki"
dims <- c(10,20,50,100)

dataname <- "netflix"

dataname <- "yahoo"

spents <- c()
outdims <- c()

for (dim in dims) {
  filename <- paste("../Results/dim_", dataname, "_d", dim, ".txt", sep="")

  df <- read.csv(filename)
  colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "sumerror", "counterror","a","b","c", "reg")
  xyplot(testrmse ~ timeout, data=df, type="l")
  goal <- df$testrmse[nrow(df)] * 1.01
  
  i1 <- min(which(df$testrmse < goal)) - 1

  if (i1 > 0) {
  
    i2 <- min(which(df$testrmse < goal))
  
    x1 <- df$timeout[i1]
    x2 <- df$timeout[i2]

    y1 <- df$testrmse[i1]
    y2 <- df$testrmse[i2]

    spent <- ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
    print(spent)

    outdims <- c(outdims, dim)
    spents <- c(spents, spent)
  }
}

plot(outdims, spents, type="b")

outname <- paste("../Results/dim_", dataname, ".txt", sep="")
tempdf <- data.frame(outdims=outdims, spents=spents)
write.table(tempdf, file=outname, sep=" ", row.names=F, col.names=F, quote=F)
