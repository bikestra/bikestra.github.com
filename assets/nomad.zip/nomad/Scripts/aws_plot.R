library(lattice)
library(plyr)

dataset <- "netflix"
goal <- 0.92

dataset <- "yahoo"
goal <- 22.5

dataset <- "hugewiki"
goal <- 0.58


datafilename <- paste("../Results/aws_nomad_", dataset, ".txt", sep="")
scalefilename <- paste("../Results/aws_nomad_", dataset, "_scale.txt", sep="")
throughputfilename <- paste("../Results/aws_nomad_", dataset, "_throughput.txt", sep="")
df <- read.csv(datafilename, header=FALSE)


colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "sumerror", "counterror","a","b","c")
# sort
df <- df[order(df$numprocs, df$timeout),]

pvvv <- ddply(df, .(numprocs), function(dd) {
  i1 <- min(which(dd$testrmse < goal)) - 1
  i2 <- min(which(dd$testrmse < goal))

  x1 <- dd$timeout[i1]
  x2 <- dd$timeout[i2]

  y1 <- dd$testrmse[i1]
  y2 <- dd$testrmse[i2]

  return ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
})

xyplot(testrmse ~ timeout | factor(numprocs), data=df, type="b")
pvvv$scale = pvvv$V1[1] / pvvv$V1 * 8
plot(pvvv$numprocs, pvvv$scale, type="b")
abline(a=0, b=1, col="red")
write.table(pvvv[,c("numprocs","scale")], file=scalefilename, sep=" ",
            row.names=F, col.names=F, quote=F)

df$throughput <- df$numupdates / df$timeout / df$numcpus / df$numprocs
write.table(df[df$timeout > 200, c("numprocs","throughput")], file=throughputfilename, sep=" ",
            row.names=F, col.names=F, quote=F)

xyplot(throughput ~ numprocs, data=df, subset=timeout > 200, ylim=c(0,1400000))
