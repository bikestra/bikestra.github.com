let unit=480189
prefix='/Users/bikestra/temp/newsynth_'
echo "prefix: "$prefix
#for size in 1 2 4 8 16 32
#for size in 1 2 
for size in 4 16 32
do
    echo "directory: "$prefix$size"/"
    mkdir $prefix$size"/"
    nrow=$(($unit * $size))
    ../Code/nomad/synthgen --nrow $nrow --output $prefix$size"/"
    cat $prefix$size"/train_header.dat" $prefix$size"/train_size.dat" $prefix$size"/train_ind.dat" $prefix$size"/train_val.dat" > $prefix$size"/train.dat"
    cat $prefix$size"/test_header.dat" $prefix$size"/test_size.dat" $prefix$size"/test_ind.dat" $prefix$size"/test_val.dat" > $prefix$size"/test.dat"
    rm $prefix$size"/"*_*.dat
done