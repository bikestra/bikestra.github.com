import os
import subprocess

#timeouts = [250, 500, 750, 1000, 1250, 1500, 1750, 2000, 4000, 6000, 8000, 10000, 12000, 14000, 16000, 18000, 20000, 25000, 30000]
#timeouts = [35000, 40000, 45000, 50000]
#timeouts = [60000, 70000, 80000, 90000, 100000]
#timeouts = [110000, 120000, 130000, 140000, 150000]
timeouts = [1000, 2000, 4000, 6000, 8000, 10000, 14000, 18000, 20000, 25000, 30000, 35000, 40000, 50000, 60000, 70000, 80000, 100000, 130000, 150000]
datasets = [("hugewikiperm", 0.01, 0.008, 0.005)]
#datasets = [("yahoo", 1.00, 0.0005, 0.05), ("netflix-trans", 0.05, 0.008, 0.01)]
#numprocs = [8, 16,32]
numprocs = [64]
numcpus = [4]
numrepeat = 1


for numproc in numprocs:
    for dataset, par_reg, lrate, drate in datasets:
        for numcpu in numcpus:
            for timeout in timeouts:
                for index in range(numrepeat):

                    real_timeout = int(float(timeout) / numproc / numcpu)

                    hours = 24 #int(float(real_timeout) / 3600 + 5)

                    task_name = "stam_proc_%s_to%d_np%d_cpu%d_l%f_r%d" % (dataset, timeout, numproc, numcpu, par_reg, index)            
                    sub_fname = "../stampede_subs/%s.sub" % (task_name)

                    ofile = open(sub_fname, "w")
            
                    ofile.write("#!/bin/sh -l \n")
                    ofile.write("# FILENAME: %s \n" % (sub_fname));

                    ofile.write("#SBATCH -J %s \n" % task_name)
                    ofile.write("#SBATCH -e ../stampede_output/%s.err \n" % task_name)
                    ofile.write("#SBATCH -o ../stampede_output/%s.out \n" % task_name)

                    ofile.write("#SBATCH -n %d\n" % numproc)
                    ofile.write("#SBATCH -N %d\n" % numproc)
                    ofile.write("#SBATCH -p normal \n")
                    ofile.write("#SBATCH -t %d:00:00 \n" % hours)
                    ofile.write("#SBATCH -A NetworkMining \n")
            
                    ofile.write("source /etc/profile.d/tacc_modules.sh \n")
                    ofile.write("export MV2_ENABLE_AFFINITY=0 \n")

                    ofile.write("export PATH=/opt/apps/gcc/4.7.1/bin:$PATH\n")
                    ofile.write("export PATH=/home1/01846/cjhsieh/newdir/cmake-2.8.10.2-Linux-i386/bin/:$PATH\n")
                    ofile.write("module load intel/13.1.1.163\n")
                    ofile.write("module load boost\n")
                    ofile.write("source /opt/apps/intel/13/composer_xe_2013.3.163/tbb/bin/tbbvars.sh intel64\n")
                    ofile.write("export BOOST_ROOT=$TACC_BOOST_DIR\n")
                    ofile.write("export CXX=icc\n")
                    
                    ofile.write("export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/apps/gcc/4.7.1/lib\n")

                    ofile.write("export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/apps/gcc/4.7.1/lib64\n")

                    ofile.write("export GCC_LIB=/opt/apps/gcc/4.7.1/lib64\n")

                    log_fname = "/scratch/01846/cjhsieh/purduedata/stampede_logs/%s.txt" % (task_name)



                    ofile.write("ibrun ../Code/nomad --timeout %d --path /scratch/01846/cjhsieh/purduedata/mc/%s --dim 100 --reg %f --lrate %f --drate %f --nthreads %d > %s \n" % (real_timeout, dataset, par_reg, lrate, drate, numcpu, log_fname) )


                    ofile.write("\n")
                    ofile.close()

                    qsub_command = "sbatch %s" % sub_fname

                    p = subprocess.Popen(qsub_command, shell=True)
                    p.communicate()
