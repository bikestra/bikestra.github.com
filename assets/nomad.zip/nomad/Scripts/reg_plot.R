library(lattice)
library(plyr)

dataname <- "hugewiki"
regs <- c("0.002500", "0.005000", "0.010000", "0.020000")

dataname <- "netflix"
regs <- c("0.000500", "0.005000", "0.050000", "0.500000")

dataname <- "yahoo"
regs <- c("0.250000", "0.500000", "1.000000", "2.000000")

spents <- c()

for (reg in regs) {
  filename <- paste("../Results/reg_", dataname, "_r", reg, ".txt", sep="")

  df <- read.csv(filename)
  colnames(df) <- c("dummy", "numprocs", "numcpus", "timeout", "numupdates", "testrmse", "sumerror", "counterror","a","b","c", "reg")
  xyplot(testrmse ~ timeout, data=df, type="l")
  
  goal <- min(df$testrmse) * 1.01
  
  i1 <- min(which(df$testrmse < goal)) - 1
  if (i1 == 0) {
    goal <- max(df$testrmse) / 1.01
    i1 <- min(which(df$testrmse > goal)) - 1
    i2 <- min(which(df$testrmse > goal))
  } else {
    i2 <- min(which(df$testrmse < goal))
  }
  x1 <- df$timeout[i1]
  x2 <- df$timeout[i2]

  y1 <- df$testrmse[i1]
  y2 <- df$testrmse[i2]

  spent <- ((goal - y1) * (x2 - x1) / (y2 - y1) + x1)
  print(spent)
  spents <- c(spents, spent)
}
outname <- paste("../Results/reg_", dataname, ".txt", sep="")
tempdf <- data.frame(regs=regs, spents=spents)
write.table(tempdf, file=outname, sep=" ", row.names=F, col.names=F, quote=F)
